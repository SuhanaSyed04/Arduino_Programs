# ThingSpeak_asukiaaa

A library to send field values to ThingSpeak.

I know the presence of [official library](https://github.com/mathworks/thingspeak-arduino) but I want to use simpler one so I make this.

# Usage

See [an example project](./examples/WriteFields/WriteFields.ino).

# License

MIT

# References

- [ThingSpeak](https://thingspeak.com/)
- [Update channel data with HTTP GET or POST](https://www.mathworks.com/help/thingspeak/writedata.html)
